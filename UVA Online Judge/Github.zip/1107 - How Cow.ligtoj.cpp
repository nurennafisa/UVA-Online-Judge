#include<bits/stdc++.h>
using namespace std;
int main()
{
    int test,x1,x2,y1,y2,x,y,m;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {
            scanf("%d%d%d%d%d",&x1,&y1,&x2,&y2,&m);
            printf("Case %d:\n",i);
            for(int j=1;j<=m;j++)
            {
                scanf("%d%d",&x,&y);
                if(x>=x1 && x<=x2 && y>=y1 && y<=y2)
                {
                    printf("Yes\n");
                }
                else
                {
                     printf("No\n");

                }
            }
        }
    }
}
