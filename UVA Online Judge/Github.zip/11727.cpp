#include <bits/stdc++.h>
using namespace std;
int main()
{
int test,a,b,c;
scanf("%d",&test);
for(int i=1;i<=test;i++)
{
    scanf("%d %d %d",&a,&b,&c);
    if(a>b)
    {
        if(a>c)
        {
           if(b>c)
           {
             printf("Case %d: %d",i,c);
           }
           else
           {
               printf("Case %d: %d",i,b);
           }
        }

     else if(b>a)
    {
        if(b>c)
        {

            if(c>a)
            {
                 printf("Case %d: %d",i,a);
            }
              else
           {
               printf("Case %d: %d",i,c);
           }

        }
    }


   else if(c>a)
    {
        if(c>b)
        {
            if(b>a)
            {
                 printf("Case %d: %d",i,a);
            }
              else
           {
               printf("Case %d: %d",i,b);
           }

        }
    }
    }

     a=0;
     b=0;
     c=0;
}


      return 0;
}





