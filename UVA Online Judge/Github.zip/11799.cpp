#include <bits/stdc++.h>
using namespace std;
int arr[10005];
int main()
{
    int test,n;
    int c=0;
    scanf("%d",&test);

  for(int i=1;i<=test;i++)
  {
       for(int j=0; ;j++)
       {
      scanf("%d",&arr[j]);
      if(j==arr[0])
      {
          break;
      }
       }
      int Max;
      Max=arr[1];
       for(int k=1;k<=arr[0];k++)
       {
           if(arr[k]>Max)
           {
               Max=arr[k];
           }
          }
          c++;
          printf("Case %d: %d",c,Max);
          printf("\n");
             memset(arr,0,sizeof arr);
  }

 return 0;
}
