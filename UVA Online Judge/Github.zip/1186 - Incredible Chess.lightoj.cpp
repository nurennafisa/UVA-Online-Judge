#include<bits/stdc++.h>
using namespace std;
int a[100][100];
int main()
{
    int test;
    int row,column,sum,r,n;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {
          scanf("%d",&n);
          for(int i=1;i<=2;i++)
          {
           for(int j=1;j<=n;j++)
          {
              scanf("%d",&a[i][j]);

          }
          }
          r=0;
          for(int i=1;i<=n;i++)
          {
              sum=0;
           for(int j=1;j<=2;j++)
          {
              sum=-(sum-a[j][i]);
          }
            r^=sum-1;
          }

          if(r==0)
            {
                printf("Case %d: black wins\n",i);
            }
            else
      {
           printf("Case %d: white wins\n",i);
      }


               memset(a,0,sizeof a);

    }
    }

       return 0;
}
