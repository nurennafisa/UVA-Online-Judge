#include<bits/stdc++.h>
using namespace std;
int a[100][100];
int main()
{
    int test;
    int row,column,sum,r;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {
            scanf("%d%d",&row,&column);

            r=0;
            for(int i=1;i<=row;i++)
            {
                     sum=0;

                for(int j=1;j<=column;j++)
                {
                    scanf("%d",&a[i][j]);
                    sum=sum+a[i][j];

                }
                r^=sum;
            }
            if(r==0)
            {
                printf("Case %d: Bob\n",i);
            }
            else
      {
           printf("Case %d: Alice\n",i);
      }
      memset(a,0,sizeof a);

    }
    }

       return 0;
}

