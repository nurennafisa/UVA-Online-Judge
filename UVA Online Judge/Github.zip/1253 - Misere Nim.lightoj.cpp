#include<bits/stdc++.h>
using namespace std;
int a[10000];
int main()
{
    int test,n,s,sum;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {
          scanf("%d",&n);

          sum=0;
          for(int i=1;i<=n;i++)
          {
              scanf("%d",&a[i]);

          }
         int c=0;
          for(int i=1;i<=n;i++)
          {
              if(a[i]==1)
              {
               c++;
              }

                sum^=a[i];

          }

           if(c==n)
           {
               if(n%2!=0)
               {
                      printf("Case %d: Bob\n",i);
               }
               else{
                  printf("Case %d: Alice\n",i);
               }
           }
          else if(sum==0)
            {
                printf("Case %d: Bob\n",i);
            }
            else
      {
           printf("Case %d: Alice\n",i);
      }
       memset(a,0,sizeof a);
        }
    }

       return 0;
}
