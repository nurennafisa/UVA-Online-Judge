#include <bits/stdc++.h>
using namespace std;
int a[100];
int main()
{
    int test,n,c=0;
     int Max;

    scanf("%d",&test);

  for(int i=1;i<=test;i++)
  {
      scanf("%d",&n);
     for(int j=0;j<n;j++)
     {
        scanf("%d",&a[j]);
     }
      int Max;
      Max=a[0];
       for(int k=0;k<n;k++)
       {
           if(a[k]>Max)
           {
               Max=a[k];
           }
          }
      c++;

         printf("Case %d: %d",c,Max);
          printf("\n");
             memset(a,0,sizeof a);
  }

  return 0;
}
