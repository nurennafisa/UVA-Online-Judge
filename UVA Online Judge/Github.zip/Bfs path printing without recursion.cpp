 #include <bits/stdc++.h>
#define pb push_back
using namespace std;
vector <int> node[1000];
int  dis[1000];
void bfs (int src,int des)
{
    dis[src] = 0;
    queue <int> q;
    q.push(src);
    while(!q.empty())
    {
        int u = q.front();
         q.pop();
        for(int i = 0; i < node[u].size(); i++)
        {
            int v = node[u][i];
            if(dis[v] == -1)
            {
                dis[v]=u;
                 q.push(v);
                if(dis[v]==des)
                {
                    return;
                }

            }
        }
    }
}
int main()
{
    int test,s;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {
   int n , e,src,des;

   cin >> n >> e;
   memset(dis,-1, sizeof dis);
   for(int i = 1; i <= e; i++)
   {
       int a, b;
       cin >> a >> b;
       node[a].pb(b);
       node[b].pb(a);
   }
cin>>src>>des;
   bfs(src,des);
   cout<<des<<" ";
  while(des!=src)
  {
      printf("%d ",dis[des]);
      des=dis[des];
  }
     for(int i=1;i<=n;i++)
     {
     node[i].clear();
         }


     }
}
return 0;
    }

/*
10
10 13
1 2
1 4
1 3
2 6
4 7
3 7
3 8
6 10
9 10
9 7
7 8
8 5
10 5
1 10
*/



