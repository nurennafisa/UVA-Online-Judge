#include <bits/stdc++.h>
using namespace std;
int visit[10000];
vector <int> node[1000];
void dfs (int u)
{
    visit[u] = 1;
    for(int i = 0; i < node[u].size(); i++)
    {
        int v = node[u][i];
        if(visit[v] == -1)
        {
            dfs(v);
        }
    }
}
int main()
{
    memset(visit,-1,sizeof visit);
    int n, e;
    cin >> n >> e;
    int a, b;
    for(int i = 0; i < e; i++)
    {
        cin >> a >> b;
        node[a].push_back(b);
        node[b].push_back(a);
    }
    dfs(1);
    int q;
    cin >> q;
    while(q--)
    {
        int x;

        cin >> x;

        if(visit[x] == 1)
            cout<<"Visit" << endl;
        else
            cout<<"Disconnected" << endl;
    }
}
