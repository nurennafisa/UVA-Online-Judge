#define gamma 0.57721566490153286060651209008240243
#define pi acos(-1.0)//also pi=M_PI, pi/2=M_PI_2 and pi/4=M_PI_4
//cos inverse (-1)=180 degree. So, 180(in degree)=pi (in radian value)
#define cos(a) (cos(a*pi/180.0))
#define sin(a) (sin(a*pi/180.0))
#define tan(a) (tan(a*pi/180.0))
#define cosi(a) (acos(a)*180.0/pi)
#define sini(a) (asin(a)*180.0/pi)
#define tani(a) (atan(a)*180.0/pi)
#define tanii(a,b) (atan2(a,b)*180.0/pi)//tan(90) = Infinity or a/0
// log(a)=ln(a) base 2.718281828459044979,, log10(a) base 10;
#define powe(a) exp(a)//e^a
//Extended Geometry
#define dis(x1,y1,x2,y2) sqrt(pow((x1-x2),2)+pow((y1-y2),2))
#define t_area(a,b,c,s) sqrt(s*(s-a)*(s-b)*(s-c))
#define t_angle(a,b,c) cosi((b*b+c*c-a*a)/(2*b*c))
//a,b,c, must be double type or in variable declaration a=3.0
using namespace std;
