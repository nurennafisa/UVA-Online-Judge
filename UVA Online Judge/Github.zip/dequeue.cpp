#include <bits/stdc++.h>
using namespace std;
int main()
{
    deque <int> d;
    d.push_back(3);//3
    d.push_back(5); // 3 5
    d.push_back(9); // 3 5 9
    d.push_front(2); // 2 3 5 9
    d.push_front(1);// 1 2 3 5 9
    d.push_back(1); // 1 2 3 5 9 1

    d.pop_front(); // 2 3 5 9 1
    d.pop_back(); // 2 3 5 9

    for(int i = 0; i < d.size(); i++)
    {
        cout<< d[i] << " ";
    }
     cout<< endl;
    int x = d.front(); ///2
    int y = d.back();/// 9
    cout<<x << " " << y << endl;


}
