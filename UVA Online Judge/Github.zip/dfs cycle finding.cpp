#include <bits/stdc++.h>
using namespace std;
int visit[10000];
vector <int> node[1000];
void dfs (int u)
{
    int v;
    visit[u] =1;
    for(int i = 0; i < node[u].size(); i++)
    {
         v = node[u][i];
        if(visit[v] == 1)
        {

    printf("Cycle!!!\n");
    break;

        }
        if(visit[v] == 0)
        {
         dfs(v);

        }
}
 visit[u]=2;

}

int main()
{
    memset(visit,0,sizeof visit);
    int n, e;
    cin >> n >> e;
    int a, b;
    for(int i = 0; i < e; i++)
    {
        cin >> a >> b;
        node[a].push_back(b);

    }

   for(int i=1;i<=n;i++)
    {

        if(visit[i]==0)
        {
            dfs(i);
        }


    }


}
/*
6 6
1 2
1 4
2 3
3 6
6 5
5 2


*/
