#include <bits/stdc++.h>
#include <stdio.h>
int mat[105][105];
using namespace std;
#define INF 99999999
void build ()
{
    for(int i = 1; i <= 101; i++)
    {
        for(int j = 1; j <= 101; j++)
        {
            if(i == j)
            {
                mat[i][j] = 0;
                continue;
            }
            mat[i][j] = INF;
        }
    }
}
void floyd (int n)
{
    for(int k = 1; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j =  1; j <= n; j++)
            {
                 mat[i][j] = min(mat[i][j], mat[i][k] + mat[k][j]);
            }
        }
    }
}
int main()
{
    build();
    int n, e;
    int x, y;
    cin >> n >> e;
    for(int i = 1; i <= e; i++)
    {
        int a, b, cost;
        cin >> a >> b >> cost;
        mat[a][b] = cost;
    }
    floyd(n);

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(mat[i][j] == INF)
            {
                printf("INF ");
                continue;
            }
            printf("%d ", mat[i][j]);
        }
        cout<< endl;
    }

}
/*
 3 4
 1 2 1
 2 3 2
 1 3 6
 3 1 5

 1 2 1 4 4 2 2 7 7 1



*/
