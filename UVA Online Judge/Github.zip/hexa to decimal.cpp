#include<bits/stdc++.h>
using namespace std;
int main()
{
  char s[10000];
    int n;
   while(scanf("%s",s)==1)
   {
       sscanf(s,"%x",&n);//string k hexa te nie n e rakhteci?
           printf("%d\n",n);





   }
}


