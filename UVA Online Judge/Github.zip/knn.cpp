#include<bits/stdc++.h>
using namespace std;
long long  int n;
double newh,neww,d1,d2,k;
double h[100000];
double w[100000];
double d[100000];
char s[100000];
void bubble (long long int n)
{

    for(int i=n-1;i>=0;i--)
    {
        for(int j=0;j<i;j++)
        {
            if(d[j]>d[j+1])
            {
                swap(d[j],d[j+1]);
                swap(h[j],h[j+1]);
                swap(w[j],w[j+1]);
                swap(s[j],s[j+1]);
            }
        }
    }
}


int main()
{


    printf("Enter the number of data :\n");
    scanf("%lld",&n);


    printf("Enter %lld data one by one...\n",n);

    for(int i=0;i<n;i++)
    {
        scanf("%lf%lf",&h[i],&w[i]);
        getchar();
        cin>>s[i];



    }


    printf("Enter the New Height & Weight & value of to predict new distance according nearest neighbour: \n");
    scanf("%lf%lf%lf",&newh,&neww,&k);
    h[n]=newh;
    w[n]=neww;

double mind=99999999999999.0,maxd=-1.0,minh=99999999999999.0,maxh=-1.0,minw=99999999999999.0,maxw=-1.0;
    for(int j=0;j<=n;j++)
    {

        if(h[j]>maxh)
        {
            maxh=h[j];
        }
        if(h[j]<minh)
        {
            minh=h[j];
        }
        if(w[j]>maxw)
        {
            maxw=w[j];
        }
        if(w[j]<minw)
        {
            minw=w[j];
        }
    }

    for(int j=0;j<n;j++)
    {


    d1=(h[j]-newh)*(h[j]-newh);
    d1=(w[j]-neww)*(w[j]-neww);
    d[j]=sqrt(d1+d2);
    if(d[j]>maxd)
        {
            maxd=d[j];
        }
        if(d[j]<mind)
        {
            mind=d[j];
        }
    }
    for(int g=0;g<n;g++)
    {
        h[g]=(h[g]-minh)/(maxh-minh);
         w[g]=(w[g]-minw)/(maxw-minw);
          d[g]=(d[g]-mind)/(maxd-mind);
          cout<<h[g]<<" "<<w[g]<<" "<<d[g]<<endl;

    }

    bubble(n);
    printf("The nearest %lf neighbours have distance & T-shirt size : \n",k);
    double t=0.0,mi=0.0;

    for(int m=0;m<k;m++)
    {

        cout<<h[m]<<" "<<w[m]<<" "<<d[m] <<" "<<s[m]<<endl;
        if(s[m]=='M')
        {
            t++;

        }
        else{
            mi++;
        }

    }
    if(t>=mi)
    {
        printf("The new T-Shirt size will be M\n");
    }
    else if(mi>=t)
    {
         printf("The new T-Shirt size will be L\n");

    }
    }


/*

18
158 58 M
158 59 M
158 63 M
160 59 M
160 60 M
163 60 M
163 61 M
160 64 L
163 64 L
165 61 L
165 62 L
165 65 L
168 62 L
168 63 L
168 66 L
170 63 L
170 64 L
170 68 L
161 61 5

11
25 40000 M
35 60000 M
45 80000 M
20 20000 M
35 120000 M
52 18000 M
23 95000 L
40 62000 L
60 100000 L
48 220000 L
33 150000 L
48 142000 3
*/
