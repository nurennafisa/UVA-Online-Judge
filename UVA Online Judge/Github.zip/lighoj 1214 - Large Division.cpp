#include <bits/stdc++.h>
using namespace std;
int main()
{ int test;
  long long int b;
  int m;
  string s;
   while(scanf("%d",&test)==1)
   {   m=0;
       for(int k=1;k<=test;k++)
       {
           m++;;
           cin>>s;
             scanf("%lld",&b);
           int sum=0;
           for(int i=0; i < s.length(); i=i+2)
        {
            sum = sum + s[i] - '0';
        }
        for(int i=1; i< s.length(); i =i+2)
        {
            sum = sum - (s[i] - '0');
        }

        if(sum % b == 0)
        {
            cout<<"Case "<<m<<": divisible"<<endl;
        }
        else
        {
             cout<<"Case "<<m<<": not divisible"<<endl;
        }

        s.clear();


       }
   }
   return 0;
}
