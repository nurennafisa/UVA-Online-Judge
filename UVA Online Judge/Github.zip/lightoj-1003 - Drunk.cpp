#include <bits/stdc++.h>
using namespace std;
int visit[ 10008];
vector <int> node[ 10008];
string s1,s2;
map<string,int>mp;
int f;
void dfs (int u)
{
    int v;
    visit[u] =1;
    for(int i = 0; i < node[u].size(); i++)
    {
         v = node[u][i];
        if(visit[v] == 1)
        {

    f=1;
    break;

        }
        if(visit[v] == 0)
        {
         dfs(v);

        }
}
 visit[u]=2;

}

int main()
{
    int test;
    scanf("%d",&test);

for(int k=1;k<=test;k++)
    {

    memset(visit,0,sizeof visit);
    int n, e;
    cin >> n;
        getchar();
    int a, b;
    int j=1;
    for(int i = 0; i < n; i++)
    {
        cin >> s1>> s2;
        if(mp[s1]==0)
        {
            mp[s1]=j;
            j++;
        }
         if(mp[s2]==0)
        {
            mp[s2]=j;
            j++;
        }
        node[mp[s1]].push_back(mp[s2]);
s1.clear();
s2.clear();
    }
j--;
f=0;
   for(int i=1;i<=j;i++)
    {

        if(visit[i]==0)
        {
            dfs(i);

        }


    }
    if(f==1)
    {
        printf("Case %d: No\n",k);
    }
else{
     printf("Case %d: Yes\n",k);
}
mp.clear();
s1.clear();
s2.clear();
for(int g=1;g<=j;g++)
{
    node[g].clear();
}
    }
}
/*
6 6
1 2
1 4
2 3
3 6
6 5
5 2


*/
