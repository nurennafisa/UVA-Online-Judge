#include<bits/stdc++.h>
using namespace std;
long long int a[1000000];
int main()
{
    int test;
    long long int g,w,sum,n;
    while(scanf("%d",&test)==1)
    {
        for(int i=1;i<=test;i++)
        {

        scanf("%lld",&n);
        for(int i=1;i<=n;i++)
        {
            scanf("%lld%lld",&g,&w);

            a[i]=w-g-1;
                    }
        sum=0;
        for(int i=1;i<=n;i++)
        {
            sum^=a[i];
        }
      if(sum==0)
      {
          printf("Case %d: Bob\n",i);
      }
      else
      {
           printf("Case %d: Alice\n",i);
      }
      memset(a,0,sizeof a);
    }
    }

    return 0;
}
