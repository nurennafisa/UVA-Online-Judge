
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n=0,test,m,num,s;
    string s1;
    deque<int>d;
    scanf("%d",&test);
    while(test--)
    {
        n++;
        scanf("%d%d",&s,&m);
         printf("Case %d:\n",n);
        for(int i=1;i<=m;i++)
        {
            cin>>s1;
            if(s1=="pushLeft" || s1=="pushRight")
            cin>>num;

            if(s1=="pushLeft")
            {
                d.push_front(num);
            if(d.size()>s)
                {

                   printf("The queue is full\n");
                   d.pop_front();

                }

                else
                {
                     printf("Pushed in left: %d\n",num);
                }
            }





            else if(s1=="pushRight")
            {
                   d.push_back(num);
            if(d.size()>s)
                {

                   printf("The queue is full\n");
                   d.pop_back();

                }

                else
                {
                     printf("Pushed in right: %d\n",num);
                }
            }


             else if(s1=="popLeft")
            {
                 if(d.size()!=0)
                {
                      printf("Popped from left: %d\n",d.front());
                      d.pop_front();


                }

                else
                {
                     printf("The queue is empty\n");
                }
            }


               else if(s1=="popRight")
            {
                 if(d.size()!=0)
                {
                      printf("Popped from right: %d\n",d.back());
                      d.pop_back();


                }

                else
                {
                     printf("The queue is empty\n");
                }
            }


            s1.clear();
        }
          d.clear();
               }
}
