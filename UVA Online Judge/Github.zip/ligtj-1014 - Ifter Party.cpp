#include <bits/stdc++.h>
using namespace std;
long long int a[10000];
int main()
{ int test;
  long long int p,l,n,m=0;
   while(scanf("%d",&test)==1)
   {
       for(int k=1;k<=test;k++)
       {
           memset(a,0,sizeof a);
           m++;
       scanf("%lld%lld",&p,&l);
       n=p-l;
       int c=0;

       for(int i=1;i<=sqrt(n);i++)
       {
           if(n%i==0)
           {
               if(i>l)
               {
                   a[c++]=i;
               }
               if(n/i!=i && n/i>l)
               {
                   a[c++]=n/i;;
               }
           }
       }
       sort(a,a+c);
       if(c==0)
           {
               printf("Case %d: impossible\n",m);
               continue;
           }
           cout<<"Case "<<m<<": ";

       for(int j=0;j<c-1;j++)
       {

               printf("%lld ",a[j]);

       }

           printf("%lld\n",a[c-1]);


   }

   }
    return 0;
}
