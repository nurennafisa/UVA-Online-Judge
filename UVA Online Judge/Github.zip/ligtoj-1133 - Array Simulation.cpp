#include<bits/stdc++.h>
using namespace std;
int a[105];
int main()
{
    int test,c,y,z,n,m;
    int add,multi,div;
    string s;

    while(scanf("%d",&test)==1)
    {
        c=0;
        for(int i=1;i<=test;i++)
        {
            c++;
            memset(a,0,sizeof a);
            s.clear();
            scanf("%d%d",&n,&m);
            for(int j=0;j<n;j++)
            {
                scanf("%d",&a[j]);
            }
            for(int k=1;k<=m;k++)
            {
                cin>>s;
                if(s=="S")
                {
                    scanf("%d",&add);
                    for(int l=0;l<n;l++)
                    {
                        a[l]=a[l]+add;

                    }

                }
                else if(s=="M")
                {
                    scanf("%d",&multi);
                    for(int l=0;l<n;l++)
                    {
                        a[l]=a[l]*multi;

                    }

                }
                else if(s=="D")
                {
                    scanf("%d",&div);
                    for(int l=0;l<n;l++)
                    {
                        a[l]=a[l]/div;

                    }
                }

                else if(s=="P")
                {
                    scanf("%d%d",&y,&z);
                    swap(a[y],a[z]);
                }
                else if(s=="R")
                {
                    reverse(a,a+n);
                }
            }
                printf("Case %d:\n",c);

                      for(int b=0;b<n-1;b++)
                    {
                        printf("%d ",a[b]);
                    }
                    printf("%d\n",a[n-1]);

        }
    }


    return 0;
}
