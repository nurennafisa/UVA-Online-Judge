#include<bits/stdc++.h>
using namespace std;
 string s1,s2,s3,s4,s5;

long long  int n;
double c1,c,yes,no;
vector< pair <string,string> > mp;

double p(string clas , string predictor)
{

  double c_p_prob,p_p_prob,likelihood,posterior_probability;
  c=0.0;
  c1=0.0;
  for(int i=0;i<n;i++)
  {
      if(mp[i].first==clas)
      {
          c++;
      }
       if(mp[i].first==clas && mp[i].second==predictor)
      {
          c1++;
      }
  }

  if(predictor=="Yes")
  {

      c_p_prob=yes/n;
      likelihood=c1/yes;


  }
   else if(predictor=="No")
  {

      c_p_prob=no/n;
likelihood=c1/no;

  }

  p_p_prob=c/n;


  posterior_probability=(likelihood* c_p_prob)/ p_p_prob;


  return posterior_probability;



}

int main()
{





    printf("Enter the number of data :\n");
    scanf("%lld",&n);
    getchar();
    printf("Enter the name of class:\n");
    cin>>s1;
    printf("Enter the name of target variable:\n");
    cin>>s2;
    printf("Enter %lld data one by one...For example: Sunny Yes\n",n);
    yes=0.0;
    no=0.0;
    for(int i=1;i<=n;i++)
    {
        cin>>s3;
        cin>>s4;
        if(s4=="Yes")
        {
            yes++;
        }
        else if(s4=="No")
        {
            no++;
        }
         mp.push_back( make_pair(s3,s4) );
         s3.clear();
         s4.clear();



    }

    printf("Enter the name of Class upon which you want to know the prediction whether Yes or No.For Example: Sunny\n");
    cin>>s5;



    double pos=p(s5,"Yes");


    double neg=p(s5,"No");

    printf("You wanted to know the prediction about ");
    cout<<s1;
    printf(" -whether to ");
    cout<<s2;
    printf(" or not\n");
    if(pos>neg)
    {
    printf("The prediction is : ''Yes''");
     printf(" with probability of %lf percent\n",pos*100);
    }
    else if(pos<neg){
         printf("The prediction is : ''No''");
         printf(" with probability of %lf percent\n",neg*100);
    }
    else{
        printf("The prediction is : Neutral\n");
    }

s1.clear();
    s2.clear();
    s3.clear();
    s4.clear();
    s5.clear();
    mp.clear();


    }


/*

14
Weather
Play
Sunny No
Overcast Yes
Rainy Yes
Sunny Yes
Sunny Yes
Overcast Yes
Rainy No
Rainy No
Sunny Yes
Rainy Yes
Sunny No
Overcast Yes
Overcast Yes
Rainy No



*/
















