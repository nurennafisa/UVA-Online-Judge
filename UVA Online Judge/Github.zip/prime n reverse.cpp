#include <bits/stdc++.h>

using namespace std;

int main()
{
    //prime

bool prime (int n)
{
    int sq = sqrt(n);

    for(int i = 2; i <= sq; i++)
    {
        if(n % i ==0)
            return false;
    }
    return true;
}

//reverse
int rev (int n)
{
    int res =0;
    while(n > 0)
    {
        res = res * 10 + n % 10;
        n /= 10;
    }
    return res;
}

return 0;

}

