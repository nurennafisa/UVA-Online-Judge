#include<bits/stdc++.h>
using namespace std;
int main()
{
    //priority quue te by default max tai de
    priority_queue <int> pq;
    The functions associated with priority queue are:
empty() � Returns whether the queue is empty
size() � Returns the size of the queue
top() � Returns a reference to the top most element of the queue
push(g) � Adds the element �g� at the end of the queue
pop() � Deletes the first element of the queue

//min priority queue
 priority_queue <int, vector<int>, greater<int> > pq;
 //pair priority queue
  priority_queue<pair<int,int>,CompareDist> pq;
}
