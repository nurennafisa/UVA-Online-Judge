 while(s3[0] == '0')
        {
            s3.erase(s3.begin());
        }
