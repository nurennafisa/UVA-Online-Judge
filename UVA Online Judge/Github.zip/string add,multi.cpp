#include <bits/stdc++.h>
using namespace std;
string z_adder(string s , int a);
string add(string a , string b);
string mul (string a, string b);
string rev (string rs);
int main()
{
   string s1 , s2;

   while(cin >> s1 >> s2)
   {
       if(s1 == "0" || s2 == "0"){
        cout<<"0"<<endl;
       continue;
       }
       cout<<mul(s1, s2) <<endl;
   }


}
string rev(string rs)
{
    reverse(rs.begin(), rs.end());
    return rs;
}
string mul(string a , string b)
{
    a = rev(a) , b = rev(b);
    int l1 = a.size() , l2 = b.size() , i , j , t , c;
    string tem , res = "";

    for(j = 0; j < l2; j++)
    {
        c = 0; tem = "";
        for(i = 0; i < l1; i++)
        {
            t=((a[i]-48)*(b[j]-48)+c);
            tem+=((t%10)+48); c=(t/10);
        }
        if(c > 0) tem += (c + 48);
        tem = z_adder(tem,j); res = add(tem,res);
    }
    return rev(res);
}
string add(string a , string b)
{
    int l1 = a.size(), l2 = b.size(), c = 0, t , i ;
    string res="";

    if(l1 < l2)
    {
        swap(a, b);
    }
    for(int i = 0; i < l1; i++)
    {
        if(i < l2)
        {
             t = (a[i] - 48) + (b[i] - 48) + c;
        }
        else
        {
            t = ( a[i] - 48) + c;
        }
        res += (( t % 10) + 48);
        c = ( t / 10);
    }
    if(c > 0 ) res +=(c + 48);
    return res;
}
string z_adder(string a, int n)
{
    string b="";
    for(int i=0; i<n; i++)
    b += "0";
    b += a;
    return b;
}
