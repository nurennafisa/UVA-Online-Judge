#include<bits/stdc++.h>
using namespace std;
int main()
{
   string s,ss;
   set<string>st;
   cin>>s;
   for(int i=0;i<s.size();i++)
   {
       for(int j=0;j<s.size();j++)
   {

       ss=s.substr(i,j);
       cout<<ss<<endl;
       st.insert(ss);
   }
   }
   set<string> :: iterator it;
   for(it=st.begin();it!=st.end();it++)
   {
       //cout<<*it<<endl;
   }
   s.clear();
   st.clear();
   //string er new line ta sort hoe set er 1st element hobe







    return 0;
}
