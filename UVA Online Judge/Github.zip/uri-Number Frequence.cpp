#include<bits/stdc++.h>
using namespace std;
int main()
{
    int test,x;
    scanf("%d",&test);
    map<int,int>mp;
    set<int>st;
    for(int i=1;i<=test;i++)
    {
        cin>>x;
        if(mp.count(x)==0)
        {
            mp[x]=1;
            st.insert(x);
        }
        else{mp[x]=mp[x]+1;
        }

    }
    map<int,int>::iterator it;
    for(it=mp.begin();it!=mp.end();it++)
    {
        cout<<it->first<<" aparece "<<it->second<<" vez(es)"<<endl;
    }

    mp.clear();
    st.clear();


    return 0;
}

