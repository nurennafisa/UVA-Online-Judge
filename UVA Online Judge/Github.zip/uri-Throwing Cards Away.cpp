#include<bits/stdc++.h>
using namespace std;
int a[100000000];
int main()
{
  queue<int>q;
  vector<int>v;

  int n;
  while(scanf("%d",&n)==1)
  {
      if(n==0)
      {
          break;
      }
      for(int i=1;i<=n;i++)
      {
          q.push(i);
      }


      for(int i=1;i<=n;i++)
      {
          a[i]=q.front();
          q.pop();
          q.push(q.front());
          q.pop();
      }
      cout<<"Discarded cards:";
          if(n==1)
          {
              cout<<""<<endl;
               cout<<"Remaining card:";
      cout<<" "<<"1"<<endl;
          }
          else{
      for(int i=1;i<n-1;i++)
      {

          cout<<" "<<a[i]<<",";
      }
      cout<<" "<<a[n-1]<<endl;


      cout<<"Remaining card:";
      cout<<" "<<a[n]<<endl;
          }
      v.clear();




  }

    return 0;
}
