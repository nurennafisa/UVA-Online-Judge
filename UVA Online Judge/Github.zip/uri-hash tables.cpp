#include<bits/stdc++.h>
using namespace std;
int main()
{
    int test,n,x,h,b,i;
    while(scanf("%d",&test)==1)
    {
        for( i=1;i<=test;i++)
        {
            scanf("%d%d",&b,&n);
            vector<int>mp[10000];

            for(int i=0;i<n;i++)
            {
                scanf("%d",&x);
                h=x%b;
              mp[h].push_back(x);
            }
            if(i!=1)
            {
                cout<<endl;
            }
            for(int i=0;i<b;i++)
            {
                cout<<i<<" -> ";
                for(int j=0;j<mp[i].size();j++)
                {
                    cout<<mp[i][j]<<" -> ";

                }
               printf("%c\n",92);

            }
            for(int i=0;i<b;i++)
            {

            mp[i].clear();
            }
        }
    }
    return 0;
}
