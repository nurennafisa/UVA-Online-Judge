#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int a,b,s1,s2;
    while(scanf("%lld%lld",&a,&b)==2)
    {
    s1=a*(a+1)/2;
    s2=b*(b+1)/2;
    s1=s2-s1+a;
    printf("%lld\n",s1);

    }

    return 0;
}
