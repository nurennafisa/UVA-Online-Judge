#include<bits/stdc++.h>
using namespace std;
 vector<string>v;
     vector<int>v1;
void bubble(int n)
{
    for(int i=n-1;i>=0;i--)
    {
        for(int j=0;j<i;j++)
        {
            if(v1[j]<v1[j+1])
            {
                 swap(v1[j],v1[j+1]);
                swap(v[j],v[j+1]);
            }
        }
    }
}
int main()
{
    string s1,s2;
    int test;
    scanf("%d",&test);
    getchar();
    for(int j=1;j<=test;j++)
    {
        getline(cin,s1);
        for(int i=0;i<s1.length();i++)
        {
            if(s1[i]!=32)
            {
                s2+=s1[i];
            }
            if(s1[i]==32 || i==s1.length()-1)
            {
                v.push_back(s2);
                s2.clear();
            }
        }
        for(int i=0;i<v.size();i++)
        {
            v1.push_back(v[i].size());
        }
        bubble(v1.size());
        for(int i=0;i<v.size()-1;i++)
        {
            cout<<v[i]<<" ";
        }
            cout<<v[v.size()-1]<<endl;

           s1.clear();
        s2.clear();
        v.clear();
        v1.clear();
    }

return 0;
}
