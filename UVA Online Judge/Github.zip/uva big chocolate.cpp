#include<bits/stdc++.h>
using namespace std;
 int main()
 {
     int r,c,result;
    while(scanf("%d%d",&r,&c)!=EOF)
    {
        result=(r*c)-1;
        printf("%d\n",result);


    }

     return 0;
 }
