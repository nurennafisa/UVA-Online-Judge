#include<bits/stdc++.h>
using namespace std;
long long int visited[100000000];
int main()
{
    long long int n,m,jack,jill;
   while(scanf("%lld%lld",&n,&m)==2)
   {
    if(n==0 && m==0)
    {
        break;
    }
       for( long long int i=0;i<n;i++)
       {

           scanf("%lld",&jack);
           visited[jack]=-1;
       }

      int c=0;
       for( long long int j=0;j<m;j++)
       {
           scanf("%lld",&jill);
           if(visited[jill]==-1)
           {
               c++;
           }
       }
       printf("%d\n",c);
      memset(visited,0,sizeof visited);

   }

  return 0;
}
