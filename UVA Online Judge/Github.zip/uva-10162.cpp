#include<bits/stdc++.h>

using namespace std;

int main()
{
    float n,p;
    int m,r;
    float sum=0;
    while(scanf("%f",&n)==1)
    {
        if(n==0)
        {
            break;
        }

        while(n>0)
        {
            p=n*n;
            sum=sum+(n-1);
            r=p+sum;
        }
           r=(int)r;
        while(sum>0)
        {
            m=r%10;
            r=r/10;
        }
        m=(int)m;

        printf("%d",m);
    }
    return 0;
}
