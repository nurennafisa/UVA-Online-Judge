#include<bits/stdc++.h>
using namespace std;

int main()
{
long long int a,b,q,l1,l2;


    while(scanf("%lld%lld",&a,&b)==2)
    {

          q=a^b;
          cout<<q<<endl;
 }
}
