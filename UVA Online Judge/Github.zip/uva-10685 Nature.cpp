#include <bits/stdc++.h>
using namespace std;
int visit[5008];
vector <int> node[5008];
int cnt;
void dfs (int u)
{
    cnt++;
    visit[u] = 1;
    for(int i = 0; i < node[u].size(); i++)
    {
        int v = node[u][i];
        if(visit[v] == -1)
        {
            dfs(v);
        }
    }
}
int main()
{
    int n, e;

    while(scanf("%d%d",&n,&e)==2)
    {
        memset(visit,-1,sizeof visit);
         map <string, int> mp;
         string a, b,s;

    if(n==0 && e==0)
    {
        break;
    }
    for(int i = 0; i < n; i++)
    {
        cin>>s;
        mp[s]=i;

    }

    for(int i = 0; i < e; i++)
    {
        cin >> a >> b;
        node[mp[a]].push_back(mp[b]);
        node[mp[b]].push_back(mp[a]);

    }
    int mx=-1;
    for(int i=0;i<n;i++)
    {
        if(visit[i]==-1)
        {
        cnt=0;
        dfs(i);
        if(mx<cnt)
                mx=cnt;
        }
    }
      cout<<mx<< endl;
   for(int i=0;i<=n;i++)
   {
       node[i].clear();
   }
   mp.clear();
   s.clear();
    a.clear();
     b.clear();

    }
}


