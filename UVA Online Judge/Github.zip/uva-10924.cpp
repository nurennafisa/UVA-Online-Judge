#include <bits/stdc++.h>

using namespace std;

bool prime (int n)
{
    int sq = sqrt(n);

    for(int i = 2; i <= sq; i++)
    {
        if(n % i ==0)
            return false;
    }
    return true;
}

int main()
{
  int sum,sum1,r,r1;
  bool result;

  string s;
  sum=0;
  sum1=0;
  while(cin>>s)
  {

  sum=0;
  sum1=0;

  for(int i=0;i<s.length();i++)
  {
      for(char j='a';j<='z';j++)
  {
      if(s[i]==j)
      {
          r=j-'0'-48;
            sum=sum+r;

      }
  }
      for(char k='A';k<='Z';k++)
  {
      if(s[i]==k)
      {
          r1=k-'0'+10;
            sum1=sum1+r1;

      }

  }


  }
  sum=sum+sum1;

  result=prime(sum);
  if(result==true)
  {
      printf("It is a prime word.");
      printf("\n");
  }
  else
  {
      printf("It is not a prime word.");
      printf("\n");
  }


  }

    return 0;
}















