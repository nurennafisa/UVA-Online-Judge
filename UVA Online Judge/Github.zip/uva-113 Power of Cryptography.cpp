#include<bits/stdc++.h>
using namespace std;
int main()
{
    double n,p,r;
    while(cin>>n>>p)
    {
    r=pow(p,1/n);
     printf("%.lf\n",r);

    }

       return 0;
}
