#include<bits/stdc++.h>

using namespace std;
int m[100];
int main()
{
  int test,n,Max,Min,result;

  scanf("%d",&test);

  for( int i=1;i<=test;i++)
  {
    scanf("%d",&n);

    for( int j=0;j<n;j++)
      {
          scanf("%d",&m[j]);

      }
          Max=m[0];

          for(int k=0;k<n;k++)
          {
          if(m[k]>Max)
          {
              Max=m[k];
          }
          }
         Min=m[0];
          for(int k=0;k<n;k++)
          {

            if(m[k]<Min)
          {
              Min=m[k];
          }
      }

      result=2*(Max-Min);
      printf("%d",result);
      printf("\n");
      memset(m,0,sizeof m);
  }

  return 0;
}
