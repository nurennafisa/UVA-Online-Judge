#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    while(scanf("%d",&n)==1)
    {
        if(n==0)
        {
            break;
        }
        if(n==3)
        {
            printf("Yes\n");
        }
        else if(n>3 && n%2==0)
        {
             printf("YES\n");
        }
        else{
             printf("NO\n");
        }
    }
}
