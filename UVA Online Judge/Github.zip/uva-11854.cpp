#include <bits/stdc++.h>
using namespace std;

int main()
{
  int a,b,c,result,test;

scanf("%d",&test);
    for(int i=1;i<=test;i++)
    {
       scanf("%d%d%d",&a,&b,&c);
          if(c>a && c>b)
          {

          if((a*a)+(b*b)==(c*c))
          {
              printf("Case %d: yes",i);
          }
          else
            {
              printf("Case %d: no",i);
          }
          }

          else if(b>a && b>a)
          {

          if((a*a)+(c*c)==(b*b))
          {
              printf("Case %d: yes",i);
          }
          else
            {
              printf("Case %d: no",i);
          }
          }


          else if(a>b && a>c)
          {

          if((c*c)+(b*b)==(a*a))
          {
              printf("Case %d: yes",i);
          }
          else
            {
              printf("Case %d: no",i);
          }
          }

          printf("\n");
          }


return 0;
}
