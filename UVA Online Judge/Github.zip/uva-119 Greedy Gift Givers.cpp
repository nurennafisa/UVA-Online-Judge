#include<bits/stdc++.h>
using namespace std;
map<string,int>mp;
map<string,int> :: iterator it;
map<int,string>mp1;
map<int,string> :: iterator it1;
string s1,s2;
int main()
{
    int n1,g,n,a,test=0;
    while(EOF)
    {
        if(test)
        {
            printf("\n");
        }
        test=1;
        scanf("%d",&n1);
        for(int i=1;i<=n1;i++)
        {
        cin>>s1;
        mp1[i]=s1;
        s1.clear();
        }

        for(int k=0;k<n1;k++)
        {
        cin>>s1;
        cin>>g>>n;

        a=g/n;
        mp[s1]=mp[s1]-(n*a);
         if(n==0)
         {
             continue;
         }


        for(int j=0;j<n;j++)
        {

            cin>>s2;
            mp[s2]=mp[s2]+a;
            s2.clear();
        }
         }
        s1.clear();




        for(it1=mp1.begin();it1!=mp1.end();it1++)
        {
            for(it=mp.begin();it!=mp.end();it++)
        {
            if(it->first==it1->second)
            cout<<it->first<<" "<<it->second<<endl;

    }
        }


    mp.clear();
    mp1.clear();
    s1.clear();
    s2.clear();


}
}

