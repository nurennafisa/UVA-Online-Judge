#include<bits/stdc++.h>
using namespace std;
int visit[10000];
vector <int> node[1000];
 double p,x,y;
 int posx,posy;
void d(double x1,double y1,double x2,double y2)
{
    double di=sqrt(((x1-x2)*(x1-x2))+((y1-y2)*(y1-y2)));
    cout<<di<<endl;
    if(di<=p)
    {
       node[posx].push_back(posy);
       node[posy].push_back(posx);
    }
}

void dfs (int u)
{
    visit[u] = 1;
    for(int i = 0; i < node[u].size(); i++)
    {
        int v = node[u][i];
        if(visit[v] == -1)
        {
            dfs(v);
        }
    }
}
int main()
{
    int n,test;

    while(scanf("%d",&test)==1)
    {
        vector< pair <double,double> >v;
        for(int m=1;m<=test;m++)
        {
            scanf("%d%lf",&n,&p);
            for(int j=0;j<n;j++)
            {
                scanf("%lf%lf",&x,&y);
                v.push_back( make_pair(x,y) );
            }
            for(int k=0;k<n;k++)
            {
                for(int l=0;l<n;l++)
                {
                    if(k==l)
                    {
                        continue;
                    }
                    posx=k;
                    posy=l;
                    d(v[k].first,v[k].second,v[l].first,v[l].second);
                }
            }
              memset(visit, -1 ,sizeof visit);
            int c = 0;
      for(int i = 0; i < n; i++)
      {
          if(visit[i] == -1)
          {
              dfs(i);
              c++;
          }
      }
      printf("Case %d: %d\n",m,c);
      for(int i=0;i<n;i++)
      {
          node[i].clear();

      }
      v.clear();

        }
    }
}
