#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a,b,c,d,e;
    while(scanf("%d%d%d%d%d",&a,&b,&c,&d,&e)==5)
    {
        if(a==0 && b==0 && c==0 && d==0 && e==0)
        {
            break;
        }
        int r=a*b*c*d*d*e*e;
         cout<<r<<endl;
    }










return 0;

    }
