#include <bits/stdc++.h>
using namespace std;
int main()
{
  string s;
  long long int test,q;
  char des,sou;
  scanf("%lld",&test);
  for(long long int i=1;i<=test;i++)
    {
       cin>>s;
       scanf("%lld",&q);

       for(long long int i=1;i<=q;i++)
       {
        cin>>des;
        cin>>sou;


           for(long long int i=0;i<s.length();i++)
           {
               if( s[i]>='A'&& s[i]<='Z')
               {
               if(s[i]==sou )
               {
                   s[i]=des;

               }
               }

           }
       }

      cout<<s<<endl;
       s.clear();

   }


return 0;
}
