#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b;
    while(scanf("%d%d",&a,&b)==2)
    {
        if(a>=b)
        {
            cout<<a<<endl;
        }
        else{
            cout<<b<<endl;
        }
    }


   return 0;
}

