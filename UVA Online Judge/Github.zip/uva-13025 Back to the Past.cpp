#include<bits/stdc++.h>
using namespace std;
int main()
{
    printf("May 29, 2013 Wednesday\n");
}
