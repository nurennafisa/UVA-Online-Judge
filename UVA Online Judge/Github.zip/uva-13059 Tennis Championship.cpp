#include<bits/stdc++.h>
using namespace std;
int main()
{

   long long int n;
   while(scanf("%lld",&n)==1)
   {

       printf("%lld\n",n-1);

}
}


